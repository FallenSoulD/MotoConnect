import 'package:flutter/material.dart';

/// MotoConnect Neumorphic (Soft UI) Renk Paleti ve Temel Değerleri
class NeuColors {
  static const Color background = Color(0xFF14161D);
  static const Color surface = Color(0xFF1E212A);
  static const Color surfaceLight = Color(0xFF272B37);
  static const Color surfaceDark = Color(0xFF111217);
  
  static const Color lightShadow = Color(0xFF2C3240);
  static const Color darkShadow = Color(0xFF090A0E);
  
  static const Color accentOrange = Color(0xFFFF5722);
  static const Color accentOrangeDark = Color(0xFFE64A19);
  static const Color accentAmber = Color(0xFFFFB300);
  static const Color accentGold = Color(0xFFFFD54F);
  static const Color accentGreen = Color(0xFF00E676);
  static const Color accentBlue = Color(0xFF2979FF);
  static const Color accentRed = Color(0xFFFF3366);
  static const Color accentCyan = Color(0xFF00E5FF);
  
  static const Color textPrimary = Colors.white;
  static const Color textSecondary = Color(0xFF9E9E9E);
  static const Color textMuted = Color(0xFF616161);
}

enum NeuStyle { raised, sunken, flat }

/// Neumorphic Kart / Konteyner
class NeuContainer extends StatelessWidget {
  final Widget? child;
  final double? width;
  final double? height;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final double borderRadius;
  final NeuStyle style;
  final Color? color;
  final Color? borderColor;
  final double borderWidth;
  final double depth;
  final VoidCallback? onTap;
  final ShapeBorder? shape;
  final Gradient? gradient;

  const NeuContainer({
    super.key,
    this.child,
    this.width,
    this.height,
    this.padding,
    this.margin,
    this.borderRadius = 18.0,
    this.style = NeuStyle.raised,
    this.color,
    this.borderColor,
    this.borderWidth = 1.0,
    this.depth = 4.0,
    this.onTap,
    this.shape,
    this.gradient,
  });

  @override
  Widget build(BuildContext context) {
    final baseColor = color ?? NeuColors.surface;

    List<BoxShadow> shadows = [];
    if (style == NeuStyle.raised) {
      shadows = [
        BoxShadow(
          color: NeuColors.lightShadow.withValues(alpha: 0.6),
          offset: Offset(-depth, -depth),
          blurRadius: depth * 2,
          spreadRadius: 0,
        ),
        BoxShadow(
          color: NeuColors.darkShadow.withValues(alpha: 0.9),
          offset: Offset(depth, depth),
          blurRadius: depth * 2,
          spreadRadius: 0,
        ),
      ];
    } else if (style == NeuStyle.sunken) {
      shadows = [
        BoxShadow(
          color: NeuColors.darkShadow.withValues(alpha: 0.75),
          offset: Offset(depth / 2, depth / 2),
          blurRadius: depth,
        ),
        BoxShadow(
          color: NeuColors.lightShadow.withValues(alpha: 0.25),
          offset: Offset(-depth / 2, -depth / 2),
          blurRadius: depth,
        ),
      ];
    }

    Widget content = Container(
      width: width,
      height: height,
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        color: gradient == null ? baseColor : null,
        gradient: gradient,
        borderRadius: BorderRadius.circular(borderRadius),
        border: borderColor != null
            ? Border.all(color: borderColor!, width: borderWidth)
            : Border.all(color: Colors.white.withValues(alpha: 0.04), width: borderWidth),
        boxShadow: shadows,
      ),
      child: child,
    );

    if (onTap != null) {
      return GestureDetector(
        onTap: onTap,
        child: content,
      );
    }
    return content;
  }
}

/// Dokunsal Neumorphic Buton
class NeuButton extends StatefulWidget {
  final Widget? child;
  final String? text;
  final IconData? icon;
  final VoidCallback? onPressed;
  final Color? color;
  final Color? textColor;
  final Color? iconColor;
  final double borderRadius;
  final EdgeInsetsGeometry padding;
  final double depth;
  final bool isLoading;
  final bool isPrimary;
  final Color? primaryGradientStart;
  final Color? primaryGradientEnd;
  final double? width;
  final double? height;

  const NeuButton({
    super.key,
    this.child,
    this.text,
    this.icon,
    this.onPressed,
    this.color,
    this.textColor,
    this.iconColor,
    this.borderRadius = 16.0,
    this.padding = const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
    this.depth = 4.0,
    this.isLoading = false,
    this.isPrimary = false,
    this.primaryGradientStart,
    this.primaryGradientEnd,
    this.width,
    this.height,
  });

  @override
  State<NeuButton> createState() => _NeuButtonState();
}

class _NeuButtonState extends State<NeuButton> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    final bool disabled = widget.onPressed == null || widget.isLoading;
    final double currentDepth = _isPressed ? 1.2 : widget.depth;

    Color baseColor = widget.color ?? (widget.isPrimary ? NeuColors.accentOrange : NeuColors.surface);
    if (disabled) {
      baseColor = baseColor.withValues(alpha: 0.5);
    }

    final List<BoxShadow> shadows = _isPressed
        ? [
            BoxShadow(
              color: NeuColors.darkShadow.withValues(alpha: 0.8),
              offset: const Offset(1.5, 1.5),
              blurRadius: 3,
            ),
          ]
        : [
            BoxShadow(
              color: widget.isPrimary
                  ? NeuColors.accentOrange.withValues(alpha: 0.3)
                  : NeuColors.lightShadow.withValues(alpha: 0.6),
              offset: Offset(-currentDepth, -currentDepth),
              blurRadius: currentDepth * 2,
            ),
            BoxShadow(
              color: NeuColors.darkShadow.withValues(alpha: 0.9),
              offset: Offset(currentDepth, currentDepth),
              blurRadius: currentDepth * 2,
            ),
          ];

    return GestureDetector(
      onTapDown: disabled ? null : (_) => setState(() => _isPressed = true),
      onTapUp: disabled
          ? null
          : (_) {
              setState(() => _isPressed = false);
              widget.onPressed?.call();
            },
      onTapCancel: disabled ? null : () => setState(() => _isPressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        width: widget.width,
        height: widget.height,
        padding: widget.padding,
        decoration: BoxDecoration(
          color: baseColor,
          gradient: widget.isPrimary
              ? LinearGradient(
                  colors: [
                    widget.primaryGradientStart ?? const Color(0xFFFF6E40),
                    widget.primaryGradientEnd ?? NeuColors.accentOrange,
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          borderRadius: BorderRadius.circular(widget.borderRadius),
          border: Border.all(
            color: widget.isPrimary
                ? Colors.white.withValues(alpha: 0.25)
                : Colors.white.withValues(alpha: 0.06),
            width: 1,
          ),
          boxShadow: shadows,
        ),
        child: widget.isLoading
            ? const Center(
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.2,
                    color: Colors.white,
                  ),
                ),
              )
            : widget.child ??
                Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (widget.icon != null) ...[
                      Icon(
                        widget.icon,
                        color: widget.iconColor ?? (widget.isPrimary ? Colors.white : Colors.white70),
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                    ],
                    if (widget.text != null)
                      Flexible(
                        child: Text(
                          widget.text!,
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: widget.textColor ?? Colors.white,
                            fontSize: 14.5,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.3,
                          ),
                        ),
                      ),
                  ],
                ),
      ),
    );
  }
}

/// Dairesel / Kare Neumorphic İkon Butonu
class NeuIconButton extends StatefulWidget {
  final IconData icon;
  final VoidCallback? onPressed;
  final Color? color;
  final Color? iconColor;
  final double size;
  final double iconSize;
  final double borderRadius;
  final bool isCircle;
  final String? tooltip;
  final bool isSelected;
  final Color? selectedColor;

  const NeuIconButton({
    super.key,
    required this.icon,
    this.onPressed,
    this.color,
    this.iconColor,
    this.size = 46.0,
    this.iconSize = 22.0,
    this.borderRadius = 14.0,
    this.isCircle = true,
    this.tooltip,
    this.isSelected = false,
    this.selectedColor,
  });

  @override
  State<NeuIconButton> createState() => _NeuIconButtonState();
}

class _NeuIconButtonState extends State<NeuIconButton> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    final double depth = (_isPressed || widget.isSelected) ? 1.5 : 3.5;
    final baseColor = widget.isSelected
        ? (widget.selectedColor ?? NeuColors.accentOrange.withValues(alpha: 0.2))
        : (widget.color ?? NeuColors.surface);

    final Widget button = GestureDetector(
      onTapDown: widget.onPressed == null ? null : (_) => setState(() => _isPressed = true),
      onTapUp: widget.onPressed == null
          ? null
          : (_) {
              setState(() => _isPressed = false);
              widget.onPressed?.call();
            },
      onTapCancel: widget.onPressed == null ? null : () => setState(() => _isPressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        width: widget.size,
        height: widget.size,
        decoration: BoxDecoration(
          color: baseColor,
          shape: widget.isCircle ? BoxShape.circle : BoxShape.rectangle,
          borderRadius: widget.isCircle ? null : BorderRadius.circular(widget.borderRadius),
          border: Border.all(
            color: widget.isSelected
                ? (widget.selectedColor ?? NeuColors.accentOrange)
                : Colors.white.withValues(alpha: 0.06),
            width: widget.isSelected ? 1.5 : 1.0,
          ),
          boxShadow: (_isPressed || widget.isSelected)
              ? [
                  BoxShadow(
                    color: NeuColors.darkShadow.withValues(alpha: 0.8),
                    offset: const Offset(1, 1),
                    blurRadius: 2,
                  ),
                ]
              : [
                  BoxShadow(
                    color: NeuColors.lightShadow.withValues(alpha: 0.5),
                    offset: Offset(-depth, -depth),
                    blurRadius: depth * 1.8,
                  ),
                  BoxShadow(
                    color: NeuColors.darkShadow.withValues(alpha: 0.85),
                    offset: Offset(depth, depth),
                    blurRadius: depth * 1.8,
                  ),
                ],
        ),
        child: Center(
          child: Icon(
            widget.icon,
            size: widget.iconSize,
            color: widget.isSelected
                ? (widget.selectedColor ?? NeuColors.accentOrange)
                : (widget.iconColor ?? Colors.white70),
          ),
        ),
      ),
    );

    if (widget.tooltip != null) {
      return Tooltip(message: widget.tooltip!, child: button);
    }
    return button;
  }
}

/// İçe Gömülü (Sunken) Neumorphic Metin Giriş Alanı
class NeuTextField extends StatefulWidget {
  final TextEditingController? controller;
  final String? labelText;
  final String? hintText;
  final IconData? prefixIcon;
  final Widget? suffixIcon;
  final bool obscureText;
  final TextInputType? keyboardType;
  final ValueChanged<String>? onChanged;
  final double borderRadius;
  final int maxLines;
  final int minLines;

  const NeuTextField({
    super.key,
    this.controller,
    this.labelText,
    this.hintText,
    this.prefixIcon,
    this.suffixIcon,
    this.obscureText = false,
    this.keyboardType,
    this.onChanged,
    this.borderRadius = 16.0,
    this.maxLines = 1,
    this.minLines = 1,
  });

  @override
  State<NeuTextField> createState() => _NeuTextFieldState();
}

class _NeuTextFieldState extends State<NeuTextField> {
  final FocusNode _focusNode = FocusNode();
  bool _isFocused = false;

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(() {
      setState(() {
        _isFocused = _focusNode.hasFocus;
      });
    });
  }

  @override
  void dispose() {
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (widget.labelText != null) ...[
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 6),
            child: Text(
              widget.labelText!,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
        Container(
          decoration: BoxDecoration(
            color: NeuColors.surfaceDark,
            borderRadius: BorderRadius.circular(widget.borderRadius),
            border: Border.all(
              color: _isFocused
                  ? NeuColors.accentOrange.withValues(alpha: 0.85)
                  : Colors.white.withValues(alpha: 0.05),
              width: _isFocused ? 1.5 : 1.0,
            ),
            boxShadow: [
              BoxShadow(
                color: NeuColors.darkShadow.withValues(alpha: 0.9),
                offset: const Offset(2, 2),
                blurRadius: 4,
                spreadRadius: -1,
              ),
              BoxShadow(
                color: NeuColors.lightShadow.withValues(alpha: 0.15),
                offset: const Offset(-1, -1),
                blurRadius: 3,
                spreadRadius: -1,
              ),
            ],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 3),
          child: TextField(
            controller: widget.controller,
            focusNode: _focusNode,
            obscureText: widget.obscureText,
            keyboardType: widget.keyboardType,
            maxLines: widget.maxLines,
            minLines: widget.minLines,
            onChanged: widget.onChanged,
            style: const TextStyle(color: Colors.white, fontSize: 14.5),
            decoration: InputDecoration(
              hintText: widget.hintText,
              hintStyle: const TextStyle(color: Colors.white30, fontSize: 13.5),
              prefixIcon: widget.prefixIcon != null
                  ? Icon(
                      widget.prefixIcon,
                      color: _isFocused ? NeuColors.accentOrange : Colors.white38,
                      size: 20,
                    )
                  : null,
              suffixIcon: widget.suffixIcon,
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ),
      ],
    );
  }
}

/// Neumorphic Sekme / Segmented Kontrolcü
class NeuSegmentedTabs extends StatelessWidget {
  final List<String> tabs;
  final int selectedIndex;
  final ValueChanged<int> onTabSelected;
  final double height;

  const NeuSegmentedTabs({
    super.key,
    required this.tabs,
    required this.selectedIndex,
    required this.onTabSelected,
    this.height = 46.0,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: NeuColors.surfaceDark,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: NeuColors.darkShadow.withValues(alpha: 0.8),
            offset: const Offset(2, 2),
            blurRadius: 4,
          ),
          BoxShadow(
            color: NeuColors.lightShadow.withValues(alpha: 0.2),
            offset: const Offset(-1, -1),
            blurRadius: 3,
          ),
        ],
      ),
      child: Row(
        children: List.generate(tabs.length, (index) {
          final isSelected = selectedIndex == index;
          return Expanded(
            child: GestureDetector(
              onTap: () => onTabSelected(index),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                decoration: BoxDecoration(
                  color: isSelected ? NeuColors.surface : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                  border: isSelected
                      ? Border.all(color: Colors.white.withValues(alpha: 0.08))
                      : null,
                  boxShadow: isSelected
                      ? [
                          BoxShadow(
                            color: NeuColors.darkShadow.withValues(alpha: 0.8),
                            offset: const Offset(2, 2),
                            blurRadius: 5,
                          ),
                          BoxShadow(
                            color: NeuColors.lightShadow.withValues(alpha: 0.4),
                            offset: const Offset(-2, -2),
                            blurRadius: 5,
                          ),
                        ]
                      : null,
                ),
                child: Center(
                  child: Text(
                    tabs[index],
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: isSelected ? NeuColors.accentOrange : Colors.white54,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                      fontSize: 13,
                    ),
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

/// Neumorphic Rozet
class NeuBadge extends StatelessWidget {
  final String text;
  final IconData? icon;
  final Color color;
  final double fontSize;
  final EdgeInsetsGeometry padding;

  const NeuBadge({
    super.key,
    required this.text,
    this.icon,
    this.color = NeuColors.accentOrange,
    this.fontSize = 11.0,
    this.padding = const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.4), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: fontSize + 2, color: color),
            const SizedBox(width: 4),
          ],
          Text(
            text,
            style: TextStyle(
              color: color,
              fontSize: fontSize,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

/// Neumorphic Kart (Başlık, İkon ve Eylemlere Sahip)
class NeuCard extends StatelessWidget {
  final String? title;
  final String? subtitle;
  final IconData? icon;
  final Color? iconColor;
  final Widget? trailing;
  final Widget? child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry? margin;
  final double borderRadius;
  final VoidCallback? onTap;
  final Color? borderColor;

  const NeuCard({
    super.key,
    this.title,
    this.subtitle,
    this.icon,
    this.iconColor,
    this.trailing,
    this.child,
    this.padding = const EdgeInsets.all(16),
    this.margin,
    this.borderRadius = 20,
    this.onTap,
    this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    return NeuContainer(
      margin: margin,
      padding: padding,
      borderRadius: borderRadius,
      borderColor: borderColor,
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          if (title != null || icon != null || trailing != null) ...[
            Row(
              children: [
                if (icon != null) ...[
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: (iconColor ?? NeuColors.accentOrange).withValues(alpha: 0.15),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(icon, color: iconColor ?? NeuColors.accentOrange, size: 18),
                  ),
                  const SizedBox(width: 10),
                ],
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (title != null)
                        Text(
                          title!,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      if (subtitle != null) ...[
                        const SizedBox(height: 2),
                        Text(
                          subtitle!,
                          style: const TextStyle(color: Colors.white54, fontSize: 12),
                        ),
                      ],
                    ],
                  ),
                ),
                ?trailing,
              ],
            ),
            if (child != null) const SizedBox(height: 14),
          ],
          ?child,
        ],
      ),
    );
  }
}

/// Dokunsal Neumorphic Toggle Switch
class NeuSwitch extends StatelessWidget {
  final bool value;
  final ValueChanged<bool> onChanged;
  final Color activeColor;

  const NeuSwitch({
    super.key,
    required this.value,
    required this.onChanged,
    this.activeColor = NeuColors.accentOrange,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onChanged(!value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 52,
        height: 30,
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          color: value ? activeColor.withValues(alpha: 0.3) : NeuColors.surfaceDark,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: value ? activeColor : Colors.white.withValues(alpha: 0.08),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: NeuColors.darkShadow.withValues(alpha: 0.8),
              offset: const Offset(2, 2),
              blurRadius: 4,
            ),
            BoxShadow(
              color: NeuColors.lightShadow.withValues(alpha: 0.2),
              offset: const Offset(-1, -1),
              blurRadius: 3,
            ),
          ],
        ),
        child: AnimatedAlign(
          duration: const Duration(milliseconds: 200),
          alignment: value ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            width: 22,
            height: 22,
            decoration: BoxDecoration(
              color: value ? activeColor : Colors.white70,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.5),
                  offset: const Offset(0, 2),
                  blurRadius: 4,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Neumorphic Liste Elemanı (Ayarlar, Profil, Menüler İçin)
class NeuListTile extends StatelessWidget {
  final Widget? leading;
  final Widget title;
  final Widget? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry? margin;
  final double borderRadius;
  final Color? color;

  const NeuListTile({
    super.key,
    this.leading,
    required this.title,
    this.subtitle,
    this.trailing,
    this.onTap,
    this.padding = const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    this.margin = const EdgeInsets.only(bottom: 10),
    this.borderRadius = 16,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return NeuContainer(
      margin: margin,
      padding: padding,
      borderRadius: borderRadius,
      color: color,
      onTap: onTap,
      child: Row(
        children: [
          if (leading != null) ...[
            leading!,
            const SizedBox(width: 14),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                title,
                if (subtitle != null) ...[
                  const SizedBox(height: 3),
                  subtitle!,
                ],
              ],
            ),
          ),
          if (trailing != null) ...[
            const SizedBox(width: 10),
            trailing!,
          ] else if (onTap != null) ...[
            const Icon(Icons.chevron_right, color: Colors.white38, size: 20),
          ],
        ],
      ),
    );
  }
}

/// Neumorphic Avatar Çerçevesi
class NeuAvatar extends StatelessWidget {
  final double radius;
  final ImageProvider? image;
  final Widget? child;
  final VoidCallback? onTap;
  final Color? borderColor;
  final double borderWidth;

  const NeuAvatar({
    super.key,
    this.radius = 40,
    this.image,
    this.child,
    this.onTap,
    this.borderColor,
    this.borderWidth = 2.0,
  });

  @override
  Widget build(BuildContext context) {
    final content = Container(
      width: radius * 2,
      height: radius * 2,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: NeuColors.surface,
        border: Border.all(
          color: borderColor ?? Colors.white.withValues(alpha: 0.1),
          width: borderWidth,
        ),
        boxShadow: [
          BoxShadow(
            color: NeuColors.lightShadow.withValues(alpha: 0.6),
            offset: const Offset(-3, -3),
            blurRadius: 6,
          ),
          BoxShadow(
            color: NeuColors.darkShadow.withValues(alpha: 0.9),
            offset: const Offset(3, 3),
            blurRadius: 6,
          ),
        ],
        image: image != null
            ? DecorationImage(
                image: image!,
                fit: BoxFit.cover,
              )
            : null,
      ),
      child: image == null ? Center(child: child) : null,
    );

    if (onTap != null) {
      return GestureDetector(onTap: onTap, child: content);
    }
    return content;
  }
}
